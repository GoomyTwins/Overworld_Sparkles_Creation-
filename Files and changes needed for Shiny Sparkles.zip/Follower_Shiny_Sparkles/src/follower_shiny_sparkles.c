#include "global.h"
#include "event_object_movement.h"
#include "field_effect.h"
#include "field_effect_helpers.h"
#include "field_weather.h"
#include "palette.h"
#include "random.h"
#include "sprite.h"
#include "task.h"
#include "wild_encounter_ow.h"
#include "follower_shiny_sparkles.h"
#include "constants/event_objects.h"

#define FOLLOWER_SHINY_GLINT_PAL_TAG 0x1015

extern const u32 gFieldEffectObjectPic_PersistentShinyGlint[];
extern const u16 gFieldEffectPalette_PersistentGlint[];

static void FollowerShinySparkleSpriteCallback(struct Sprite *sprite)
{
    if (sprite->animEnded)
        DestroySprite(sprite);
}

static const struct SpriteFrameImage sPicTable_PersistentShinyGlint[] = {
    overworld_frame(gFieldEffectObjectPic_PersistentShinyGlint, 1, 1, 0),
    overworld_frame(gFieldEffectObjectPic_PersistentShinyGlint, 1, 1, 1),
    overworld_frame(gFieldEffectObjectPic_PersistentShinyGlint, 1, 1, 2),
    overworld_frame(gFieldEffectObjectPic_PersistentShinyGlint, 1, 1, 3),
};

static const union AnimCmd sAnim_PersistentShinyGlint[] = {
    ANIMCMD_FRAME(0, 3),
    ANIMCMD_FRAME(1, 4),
    ANIMCMD_FRAME(2, 4),
    ANIMCMD_FRAME(3, 4),
    ANIMCMD_END,
};

static const union AnimCmd *const sAnimTable_PersistentShinyGlint[] = {
    sAnim_PersistentShinyGlint,
};

const struct SpritePalette gSpritePalette_PersistentGlint = {
    gFieldEffectPalette_PersistentGlint,
    FOLLOWER_SHINY_GLINT_PAL_TAG
};

const struct SpriteTemplate gFieldEffectObjectTemplate_PersistentShinySparkle = {
    .tileTag = TAG_NONE,
    .paletteTag = FOLLOWER_SHINY_GLINT_PAL_TAG,
    .oam = &gObjectEventBaseOam_8x8,
    .anims = sAnimTable_PersistentShinyGlint,
    .images = sPicTable_PersistentShinyGlint,
    .affineAnims = gDummySpriteAffineAnimTable,
    .callback = FollowerShinySparkleSpriteCallback,
};

extern const struct SpriteTemplate
    gFieldEffectObjectTemplate_PersistentShinySparkle;

static bool8 IsFollowerSparklePixelVisible(
    const struct Sprite *sprite, s16 x, s16 y)
{
    u16 width, height, tile, pixel;
    const u8 *graphics;
    u8 value;

    if (sprite->oam.affineMode != ST_OAM_AFFINE_OFF
     || sprite->oam.bpp != ST_OAM_4BPP)
        return FALSE;

    width = gOamDimensions[sprite->oam.shape][sprite->oam.size].width;
    height = gOamDimensions[sprite->oam.shape][sprite->oam.size].height;
    if (x < 0 || y < 0 || x >= width || y >= height)
        return FALSE;

    if (sprite->oam.matrixNum & 8)
        x = width - 1 - x;
    if (sprite->oam.matrixNum & 16)
        y = height - 1 - y;

    tile = (y / 8) * (width / 8) + x / 8;
    pixel = (y % 8) * 8 + x % 8;
    graphics = (const u8 *)OBJ_VRAM0
             + (sprite->oam.tileNum + tile) * TILE_SIZE_4BPP;
    value = graphics[pixel / 2];
    return ((pixel & 1 ? value >> 4 : value) & 15) != 0;
}

static bool8 IsFollowerSparkleEdgePixel(
    const struct Sprite *sprite, s16 x, s16 y)
{
    s16 dx, dy;

    if (IsFollowerSparklePixelVisible(sprite, x, y))
        return FALSE;

    for (dy = -2; dy <= 2; dy++)
        for (dx = -2; dx <= 2; dx++)
            if (dx * dx + dy * dy <= 4
             && IsFollowerSparklePixelVisible(
                    sprite, x + dx, y + dy))
                return TRUE;

    return FALSE;
}

static bool8 IsFollowerShinySparkleSprite(u8 spriteId);

static bool8 PickFollowerSparklePosition(
    const struct Sprite *sprite,
    const struct ObjectEventGraphicsInfo *graphicsInfo,
    const struct Task *task,
    s16 *x,
    s16 *y)
{
    u16 width = graphicsInfo->width;
    u16 height = graphicsInfo->height;
    u8 i;
    s16 minSeparation = 10;

    if (width >= 64 || height >= 64)
        minSeparation = 12;

    for (i = 0; i < 32; i++)
    {
        s16 px = Random() % width;
        s16 py = Random() % height;
        s16 candidateX;
        s16 candidateY;
        u8 slot;
        bool8 wantEdge;
        bool8 tooClose = FALSE;

        wantEdge = (Random() % 100) < 15;

        if (wantEdge)
        {
            if (!IsFollowerSparkleEdgePixel(sprite, px, py))
                continue;
        }
        else if (!IsFollowerSparklePixelVisible(sprite, px, py))
        {
            continue;
        }

        candidateX = px - width / 2;
        candidateY = py - height / 2;

        for (slot = 0; slot < 4; slot++)
        {
            s16 sparkleId = task->data[1 + slot];
            s16 sparkleX;
            s16 sparkleY;
            s16 dx;
            s16 dy;

            if (!IsFollowerShinySparkleSprite(sparkleId))
                continue;

            sparkleX = gSprites[sparkleId].x
                     - sprite->x
                     - sprite->x2;
            sparkleY = gSprites[sparkleId].y
                     - sprite->y
                     - sprite->y2;

            dx = candidateX - sparkleX;
            dy = candidateY - sparkleY;

            if (dx * dx + dy * dy
                < minSeparation * minSeparation)
            {
                tooClose = TRUE;
                break;
            }
        }

        if (tooClose)
            continue;

        *x = candidateX;
        *y = candidateY;
        return TRUE;
    }

    return FALSE;
}

static u8 SpawnFollowerShinySparkle(s16 x, s16 y, u8 subpriority)
{
    extern const struct SpritePalette gSpritePalette_PersistentGlint;
    u32 spriteId;

    FieldEffect_LoadFadedPalette(
        (struct SpritePalette *)&gSpritePalette_PersistentGlint,
        COLOR_MAP_DARK_CONTRAST);

    spriteId = CreateSpriteAtEndUnchecked(
        &gFieldEffectObjectTemplate_PersistentShinySparkle,
        x, y, subpriority);

    if (spriteId == MAX_SPRITES)
        return MAX_SPRITES;

    gSprites[spriteId].coordOffsetEnabled = TRUE;
    gSprites[spriteId].data[7] = 0x4C53;
    return spriteId;
}
static struct Sprite *GetFollowerShinyObjectSprite(u8 objectEventId)
{
    struct ObjectEvent *objectEvent;

    if (objectEventId >= OBJECT_EVENTS_COUNT)
        return NULL;

    objectEvent = &gObjectEvents[objectEventId];

    if (!objectEvent->active
     || objectEvent->spriteId >= MAX_SPRITES
     || !gSprites[objectEvent->spriteId].inUse)
        return NULL;

    return &gSprites[objectEvent->spriteId];
}

static bool8 IsFollowerShinySparkleTarget(u8 objectEventId)
{
    struct ObjectEvent *objectEvent;

    if (objectEventId >= OBJECT_EVENTS_COUNT)
        return FALSE;

    objectEvent = &gObjectEvents[objectEventId];

    return objectEvent->active
        && (objectEvent->graphicsId & OBJ_EVENT_MON)
        && OW_SHINY(objectEvent);
}

static bool8 IsFollowerShinySparkleSprite(u8 spriteId)
{
    return spriteId < MAX_SPRITES
        && gSprites[spriteId].inUse
        && gSprites[spriteId].template ==
           &gFieldEffectObjectTemplate_PersistentShinySparkle
        && gSprites[spriteId].data[7] == 0x4C53;
}

static void DestroyFollowerShinySparkleSlot(s16 *spriteId)
{
    if (*spriteId < MAX_SPRITES
     && IsFollowerShinySparkleSprite(*spriteId))
        DestroySprite(&gSprites[*spriteId]);

    *spriteId = MAX_SPRITES;
}


static void Task_FollowerShinySparkle(u8 taskId)
{
    struct Task *task = &gTasks[taskId];
    struct ObjectEvent *objectEvent;
    struct Sprite *resident;
    const struct ObjectEventGraphicsInfo *graphicsInfo;
    s16 *slot;
    s16 offsetX;
    s16 offsetY;
    u8 objectEventId = task->data[5];
    u8 i;

    
    if (objectEventId >= OBJECT_EVENTS_COUNT
     || !gObjectEvents[objectEventId].active)
    {
        for (i = 0; i < 4; i++)
            DestroyFollowerShinySparkleSlot(&task->data[1 + i]);

        DestroyTask(taskId);
        return;
    }

    objectEvent = &gObjectEvents[objectEventId];

    if (!IsFollowerShinySparkleTarget(objectEventId))
    {
        for (i = 0; i < 4; i++)
            DestroyFollowerShinySparkleSlot(&task->data[1 + i]);

        return;
    }

    
    if (objectEvent->invisible)
    {
        for (i = 0; i < 4; i++)
            DestroyFollowerShinySparkleSlot(&task->data[1 + i]);

        return;
    }

    
    resident = GetFollowerShinyObjectSprite(objectEventId);
    if (resident == NULL)
        return;

    
    if (task->data[6] != objectEvent->spriteId
     || task->data[7] != objectEvent->graphicsId)
    {
        for (i = 0; i < 4; i++)
            DestroyFollowerShinySparkleSlot(&task->data[1 + i]);

        task->data[6] = objectEvent->spriteId;
        task->data[7] = objectEvent->graphicsId;
        task->data[0] = 0;
        task->data[8] = 0;
        return;
    }

    
    for (i = 0; i < 4; i++)
    {
        if (task->data[1 + i] < MAX_SPRITES
         && !IsFollowerShinySparkleSprite(task->data[1 + i]))
            task->data[1 + i] = MAX_SPRITES;
    }

    if (++task->data[0] < 12)
        return;

    task->data[0] = 0;

    slot = &task->data[1 + (task->data[8] & 3)];

    
    if (*slot < MAX_SPRITES)
        return;

    graphicsInfo = GetObjectEventGraphicsInfo(objectEvent->graphicsId);

    if (!PickFollowerSparklePosition(
            resident,
            graphicsInfo,
            task,
            &offsetX,
            &offsetY))
        return;

    *slot = SpawnFollowerShinySparkle(
        resident->x + resident->x2 + offsetX,
        resident->y + resident->y2 + offsetY,
        resident->subpriority > 0
            ? resident->subpriority - 1
            : 0);

    if (*slot < MAX_SPRITES)
        task->data[8] = (task->data[8] + 1) & 3;
}

static bool8 IsFollowerShinySparkleTaskForObject(
    u8 taskId, u8 objectEventId)
{
    return gTasks[taskId].func == Task_FollowerShinySparkle
        && gTasks[taskId].data[5] == objectEventId;
}

void StartFollowerShinySparkles(u8 objectEventId)
{
    struct Sprite *resident;
    u8 taskId;

    if (!IsFollowerShinySparkleTarget(objectEventId))
        return;

    resident = GetFollowerShinyObjectSprite(objectEventId);
    if (resident == NULL)
        return;

    for (taskId = 0; taskId < NUM_TASKS; taskId++)
    {
        if (IsFollowerShinySparkleTaskForObject(taskId, objectEventId))
            return;
    }

    taskId = CreateTask(Task_FollowerShinySparkle, 81);
    if (taskId == NUM_TASKS)
        return;

    gTasks[taskId].data[0] = 0;
    gTasks[taskId].data[1] = MAX_SPRITES;
    gTasks[taskId].data[2] = MAX_SPRITES;
    gTasks[taskId].data[3] = MAX_SPRITES;
    gTasks[taskId].data[4] = MAX_SPRITES;
    gTasks[taskId].data[5] = objectEventId;
    gTasks[taskId].data[6] = gObjectEvents[objectEventId].spriteId;
    gTasks[taskId].data[7] = gObjectEvents[objectEventId].graphicsId;
    gTasks[taskId].data[8] = 0;

    return;
}

