#ifndef GUARD_FOLLOWER_SHINY_SPARKLES_H
#define GUARD_FOLLOWER_SHINY_SPARKLES_H

void StartFollowerShinySparkles(u8 objectEventId);

#endif
